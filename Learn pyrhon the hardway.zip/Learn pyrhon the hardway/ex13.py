from sys import argv
script, first, second, third = argv

print("The script is", script)
print("your verv",first)
print("Your sec",second)
print("your third",third)
print(input(argv))
