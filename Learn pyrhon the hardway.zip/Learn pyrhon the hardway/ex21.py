def add(a, b):
    print(f"ADDING {a} + {b}")
    return a + b

def subtract(a, b):
    print(f"SUB {a} - {b}")
    return a - b

def multiply(a, b):
    print(f"Mul {a} * {b}")
    return a * b

def divide(a, b):
    print(f"Div {a} / {b}")
    return a / b

print(" some func")

age = add(30, 5)
height = subtract(78, 4)
weight = multiply(90, 2)
iq =  divide(100, 2)

print(f"Age:{age}, Height:{height}, Weight:{weight}, IQ:{iq}")

print("Puzzle")
what = add(age, subtract(height, multiply(weight,divide(iq, 2))))

print("That becomes: ", what," can you do it by hand?")
