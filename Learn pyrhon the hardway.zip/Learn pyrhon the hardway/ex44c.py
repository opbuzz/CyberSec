class Parent():
    def alterd(self):
        print("PARENT alterd()")
class Child(Parent):

    def alterd(self):
        print("CHILD, BEFORE PARENT alterd()")
        super(Child, self).alterd()
        print("CHILD, AFTER PARENT alterd()")

dad = Parent()
son = Child()

dad.alterd()
son.alterd()
