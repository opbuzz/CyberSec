tabby_cat = "\ti'm tabbed in."
persian_cat = "i'm split\non a line"
backslash_cat = "i'm \\ a \\ cat."

fat_cat = """
me list
\t* cat foot
\t* Finshies
\t* Catnip\n\t* Grass
"""

print(tabby_cat)
print(persian_cat)
print(backslash_cat)
print(fat_cat)
print("\a"+'bla\a bla')
print("some\rtext\r and     \r more")
